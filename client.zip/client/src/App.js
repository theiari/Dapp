
import { BigNumber, ethers } from "ethers";
import { getAddress } from "ethers/lib/utils";
import React, { useEffect, useState } from "react";
import {ABI_CONTRATTO, INDIRIZZO_CONTRATTO } from './config'

function App() {
  
   const[offerta, setOfferta] = useState('');
   const[depositValue, setDepositValue]= useState('');
   const[valoreOfferta, setValoreOfferta]= useState('');
   const [balance, setBalance] = useState();
   const [blocco, setBlocco] = useState();
   const provider = new ethers.providers.Web3Provider(window.ethereum)
   const signer = provider.getSigner();
   const[errore, setErrore] = useState('');
   const[indirizzo, setIndirizzo] = useState('');
   const[offerenteMax, setOfferenteMax] = useState('');

// The ERC-20 Contract ABI, which is a common contract interface
// for tokens (this is the Human-Readable ABI format)
/*const ABI = [
      {
        "inputs": [
          {
            "internalType": "string",
            "name": "_greeting",
            "type": "string"
          }
        ],
        "stateMutability": "nonpayable",
        "type": "constructor"
      },
      {
        "inputs": [],
        "name": "deposit",
        "outputs": [],
        "stateMutability": "payable",
        "type": "function"
      },
      {
        "inputs": [],
        "name": "greet",
        "outputs": [
          {
            "internalType": "string",
            "name": "",
            "type": "string"
          }
        ],
        "stateMutability": "view",
        "type": "function"
      },
      {
        "inputs": [
          {
            "internalType": "string",
            "name": "_greeting",
            "type": "string"
          }
        ],
        "name": "setGreeting",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
      },
      {
        "inputs": [],
        "name": "striscia",
        "outputs": [
          {
            "internalType": "string",
            "name": "",
            "type": "string"
          }
        ],
        "stateMutability": "pure",
        "type": "function"
      }
    ];*/


const contract = new ethers.Contract(INDIRIZZO_CONTRATTO, ABI_CONTRATTO, signer);

// The Contract object


       

  // A Web3Provider wraps a standard Web3 provider, which is
  // what MetaMask injects as window.ethereum into each page
  

  // MetaMask requires requesting permission to connect users accounts
  useEffect(() => {
  const connectWallet = async() => {
   await provider.send("eth_requestAccounts", []);
  }

  const getBalance = async () =>{
      
  
  // Get the balance of an account (by address or ENS name, if supported by network)
  const balance = await provider.getBalance(await signer.getAddress()) //il signer cambia di volta in volta, in base a chi sta effettuando una nuova offerta
  // { BigNumber: "182826475815887608" }
  // Often you need to format the output to something more user-friendly,
  // such as in ether (instead of wei)
  const balanceFormatted = ethers.utils.formatUnits(balance);
  
  // '0.182826475815887608'

  setBalance(balanceFormatted);

  }


  const getIndirizzo = async () =>{
       setIndirizzo(await signer.getAddress())
  }

  const getOfferenteMax = async () =>{

    const offerente = await contract.getOfferenteMax();
    setOfferenteMax(ethers.utils.getAddress(offerente));
  }
  const getBlocco = async () =>{
    const blocco = await provider.getTransactionCount(getIndirizzo())
    setBlocco(blocco);
  }


  
  const getOfferta = async () => {
      const offerta = await contract.getOfferta(); //chiamata al metodo del contratto "Greeter.sol"
      const offertaFormatted = ethers.utils.formatUnits(offerta);
     setOfferta(offertaFormatted);
     // console.log(offertaFormatted)
      
  }
  
  
  connectWallet()
    .catch(console.error);
    getBalance().catch(console.error);
   // getBlocco().catch(console.error);
    getOfferta().catch(console.error);
    getOfferenteMax().catch(console.error);
    getIndirizzo().catch(console.error);
 })
  // The MetaMask plugin also allows signing transactions to
  // send ether and pay to change state within the blockchain.
  // For this, you need the account signer...
    

 
    

    const gestisciDepositChange = (e) =>{
       
        setDepositValue(e.target.value);
    }

    const gestisciOfferta = (e) =>{
         setValoreOfferta(e.target.value);

    }

    const submitDeposit = (e) =>{
        e.preventDefault();
        console.log(depositValue);

    }
   // const { ethereum } = window;
    const submitOfferta = async (e) =>{
      e.preventDefault();
      if (valoreOfferta < offerta){
       
          setErrore("Offerta troppo bassa!");
      }
      else{

        /*ethereum
        .request({
          method: 'eth_sendTransaction',
          params: [
            {
              from: provider._getAddress(),
              to: 'INDIRIZZO_CONTRATTO',
              value: valoreOfferta,
              gasPrice: '0x09184e72a000',
              gas: '0x2710',
            },
          ],
        })
        .then((txHash) => console.log(txHash))
        .catch((error) => console.error);*/
        const OffertaBig = BigNumber.from(valoreOfferta); //cast del valoreOfferta in BigNumber
       // offerenteMax = ethers.utils.getAddress(await signer.getAddress()); //se l'offerta è stata registrata, vuol dire che è l'indirizzo attuale è il maggiore offerente
      await contract.setOfferta({value: ethers.utils.parseEther(valoreOfferta)});
      
        setOfferta(valoreOfferta);
        setValoreOfferta(0);
        //setErrore('');
      }

   
    } 

    


    return (
    <div className=" pagewrap">
     <div className="container ">
        <div className="form">
         <div className="center">
            <span> </span>
          <h3> Indirizzo attuale : {indirizzo} </h3>
            <h3> saldo attuale : {balance} ETH</h3>
            <h3> Offerta più alta : {offerta} ETH da {offerenteMax} </h3>
            </div>
            <p></p>
              <form className="center"onSubmit={submitOfferta}>
              <div className="">
                
              <input type="number" className="form-control"  onChange={gestisciOfferta} value={valoreOfferta} />
              <p></p>
                <button type="submit" className="btn btn-primary topnav">Offri</button>
               <span> </span>
                </div>
                
              </form>
          </div>
        </div>
      </div>
    
  );
}

export default App;
